package com.apexgroup.emplyeemanagement.Services;

import com.apexgroup.emplyeemanagement.Entities.employee;
import com.apexgroup.emplyeemanagement.Repositories.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    private EmployeeRepo employeeRepo;
    @Autowired
    public EmployeeService(EmployeeRepo employeeRepo) {
        this.employeeRepo = employeeRepo;
    }

    public List<employee> findAll() {
        return employeeRepo.findAll();
    }

    public employee findById(int id) {
        return employeeRepo.findById(id).orElse(null);
    }

    public employee save(employee employee) {
        return employeeRepo.save(employee);
    }

    public void deleteById(int id) {
        employeeRepo.deleteById(id);
    }

    public employee update(employee employee) {
        employee obj = employeeRepo.findById(employee.getId()).orElse(null);
        obj.setName(employee.getName());
        obj.setDepartment(employee.getDepartment());
        obj.setEmail(employee.getEmail());
        obj.setStatus(employee.getStatus());
        obj.setPosition(employee.getPosition());
        obj.setHireDate(employee.getHireDate());
        obj.setPhone(employee.getPhone());
        return employeeRepo.save(obj);
    }
}

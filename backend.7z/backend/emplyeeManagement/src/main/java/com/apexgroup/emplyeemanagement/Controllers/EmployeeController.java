package com.apexgroup.emplyeemanagement.Controllers;

import com.apexgroup.emplyeemanagement.Entities.employee;
import com.apexgroup.emplyeemanagement.Services.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {
    private EmployeeService service;
    @Autowired
    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List> getEmployees(){
        List<employee> employees = service.findAll();
        return ResponseEntity.ok().body(employees);
    }

    @GetMapping("/{id}")
    public ResponseEntity<employee> getEmployeeById(@PathVariable int id){
        employee employee = service.findById(id);
        return ResponseEntity.ok().body(employee);
    }

    @PostMapping
    public ResponseEntity<employee> saveEmployee(@RequestBody employee employee){
        employee save =  service.save(employee);
        return ResponseEntity.ok().body(save);
    }

    @PutMapping("/{id}")
    public ResponseEntity<employee> updateEmployee(@PathVariable int id, @RequestBody employee employee){
        employee.setId(id);
        employee updated = service.update(employee);
        return ResponseEntity.ok().body(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<employee> deleteEmployee(@PathVariable int id){
        service.deleteById(id);
        return ResponseEntity.ok().build();
    }
}

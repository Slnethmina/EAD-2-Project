package com.apexgroup.emplyeemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmplyeeManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
